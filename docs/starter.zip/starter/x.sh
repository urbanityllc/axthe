
clear
npm i -g npm
npm i -g npm-check-updates
ncu
npm i
npm start