
clear
npm i -g npm
npm i
npm start