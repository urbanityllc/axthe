
clear
npm i -g npm
npx ncu
npm i
npm start