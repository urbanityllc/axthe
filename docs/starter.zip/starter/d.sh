
clear
npm i -g npm
npm i -g npm-check-updates
ncu
npm i

# uses nodemon to monitor js in lib
npm start