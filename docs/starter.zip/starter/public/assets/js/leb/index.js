/* eslint-disable linebreak-style */
//https://github.com/PierfrancescoSoffritti/light-event-bus.js
import _EventBus from '/assets/js/leb/EventBus.js';

export const EventBus = _EventBus;
export const EventBusSingleton = new _EventBus();
