clear
caddy version
caddy validate
# caddy start
caddy reload




